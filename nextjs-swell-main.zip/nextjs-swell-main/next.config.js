module.exports = {
  reactStrictMode: true,
  images: {
    domains: ['cdn.schema.io'],
  },
}
